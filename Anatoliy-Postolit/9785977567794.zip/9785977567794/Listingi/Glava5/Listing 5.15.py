# Listing 5.15
def index(request):
    return render(request, "firstapp/home.html")





