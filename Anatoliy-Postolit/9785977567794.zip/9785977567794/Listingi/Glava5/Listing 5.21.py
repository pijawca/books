# Listing 5.21
STATICFILES_DIRS = [
    os.path.join(BASE_DIR, "static"),
]






