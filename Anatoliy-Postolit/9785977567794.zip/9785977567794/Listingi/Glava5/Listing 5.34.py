# Listing 5.34
def index(request):
    return render(request, "firstapp/index.html")
