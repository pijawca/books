# Listing 10.12
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'
