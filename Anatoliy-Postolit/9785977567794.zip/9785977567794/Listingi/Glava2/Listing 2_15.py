# Listing 2.15
for i in [1, 10, 100, 1000]:
    print(i * 2)
