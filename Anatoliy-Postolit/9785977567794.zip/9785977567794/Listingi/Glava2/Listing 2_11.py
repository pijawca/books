# Листинг 2.11
x = 12
if (x < 10):
    x = x / 2
else:
    x = x * 2
print(x)
