# Listing 2.14
for x in range(1, 101):
    print("Квадрат числа " + str(x) + " равен " + str(x**2))
