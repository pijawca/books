# Listing 2.10
x = 8
if (x < 10):
    x = x / 2
else:
    x = x * 2
print(x)
