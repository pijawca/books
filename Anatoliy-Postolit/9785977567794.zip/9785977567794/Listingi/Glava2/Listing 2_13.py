# Listing 2.13
x = 1
while x <= 100:
    print("Квадрат числа " + str(x) + " равен " + str(x**2))
    x = x + 1
