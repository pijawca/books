# Listing 2.8
def f_sum(a, b):
    result = a + b
    return result

# Listing 2.9
s = f_sum(2, 3)
print(s)
